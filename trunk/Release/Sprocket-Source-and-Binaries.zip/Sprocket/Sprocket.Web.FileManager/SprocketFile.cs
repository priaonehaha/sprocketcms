using System;
using System.Collections.Generic;
using System.Data;
using System.Web;
using System.IO;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Xml;

using Sprocket;
using Sprocket.Web;
using Sprocket.Data;

// make it so i can "generate" a thumbnail out of any file at any size or style, using the default icons if it's not an image

namespace Sprocket.Web.FileManager
{
	public class SprocketFile : DataEntity
	{
		#region Fields

		protected Guid? sprocketFileID = null;
		protected Guid? ownerID = null;
		protected Guid? parentFileID = null;
		protected Guid? clientID = null;
		protected string fileTypeExtension = "";
		protected string sprocketPath = "";
		protected string contentType = "";
		protected string categoryCode = "";
		protected string moduleRegCode = "";
		protected string description = "";
		protected DateTime uploadDate = DateTime.Now;

		#endregion

		#region Constructors

		public SprocketFile()
		{
		}

		public SprocketFile(DataRow row)
		{
			sprocketFileID = row["SprocketFileID"] == DBNull.Value ? null : (Guid?)row["SprocketFileID"];
			ownerID = row["OwnerID"] == DBNull.Value ? null : (Guid?)row["OwnerID"];
			parentFileID = row["ParentFileID"] == DBNull.Value ? null : (Guid?)row["ParentFileID"];
			if (row["FileTypeExtension"] != DBNull.Value) fileTypeExtension = (string)row["FileTypeExtension"];
			if (row["SprocketPath"] != DBNull.Value) sprocketPath = (string)row["SprocketPath"];
			if (row["ContentType"] != DBNull.Value) contentType = (string)row["ContentType"];
			if (row["CategoryCode"] != DBNull.Value) categoryCode = (string)row["CategoryCode"];
			if (row["ModuleRegCode"] != DBNull.Value) moduleRegCode = (string)row["ModuleRegCode"];
			if (row["Description"] != DBNull.Value) description = (string)row["Description"];
			if (row["ClientID"] != DBNull.Value) clientID = (Guid?)row["ClientID"];
			IsNew = false;
			WasNew = false;
		}

		#endregion

		#region Class Properties

		public Guid? SprocketFileID
		{
			get { return sprocketFileID; }
			set { sprocketFileID = value; }
		}

		public Guid? OwnerID
		{
			get { return ownerID; }
			set { ownerID = value; }
		}

		public Guid? ParentFileID
		{
			get { return parentFileID; }
			set { parentFileID = value; }
		}

		public Guid? ClientID
		{
			get { return clientID; }
			set { clientID = value; }
		}

		public string FileTypeExtension
		{
			get { return fileTypeExtension; }
			set { fileTypeExtension = value.ToLower().Trim('.'); }
		}

		public string SprocketPath
		{
			get { return sprocketPath; }
			set { sprocketPath = value; }
		}

		public string ContentType
		{
			get { return contentType; }
			set { contentType = value; }
		}

		public string CategoryCode
		{
			get { return categoryCode; }
			set { categoryCode = value; }
		}

		public string ModuleRegCode
		{
			get { return moduleRegCode; }
			set { moduleRegCode = value; }
		}

		public string Description
		{
			get { return description; }
			set { description = value; }
		}

		public DateTime UploadDate
		{
			get { return uploadDate; }
			set { uploadDate = value; }
		}

		#endregion

		#region Data Parameter Handling

		protected void AddParameters(IDbCommand cmd)
		{
			Database.Main.AddParameter(cmd, "@SprocketFileID", SprocketFileID);
			Database.Main.AddParameter(cmd, "@OwnerID", OwnerID);
			Database.Main.AddParameter(cmd, "@ParentFileID", ParentFileID);
			Database.Main.AddParameter(cmd, "@FileTypeExtension", FileTypeExtension);
			Database.Main.AddParameter(cmd, "@SprocketPath", SprocketPath);
			Database.Main.AddParameter(cmd, "@ContentType", ContentType);
			Database.Main.AddParameter(cmd, "@CategoryCode", CategoryCode);
			Database.Main.AddParameter(cmd, "@ModuleRegCode", ModuleRegCode);
			Database.Main.AddParameter(cmd, "@Description", Description);
			Database.Main.AddParameter(cmd, "@ClientID", ClientID);
			Database.Main.AddParameter(cmd, "@UploadDate", UploadDate);
		}

		#endregion

		#region Saving and Loading

		public Guid Save()
		{
			string procName = IsNew ? "InsertSprocketFile" : "UpdateSprocketFile";
			if (SprocketFileID == null) SprocketFileID = Guid.NewGuid();
			IDbCommand cmd = Database.Main.CreateCommand(procName, CommandType.StoredProcedure);
			AddParameters(cmd);
			cmd.ExecuteNonQuery();
			SetSaved();
			return SprocketFileID.Value;
		}

		public static void Delete(Guid sprocketfileID)
		{
			IDbCommand cmd = Database.Main.CreateCommand("DeleteSprocketFile", CommandType.StoredProcedure);
			Database.Main.AddParameter(cmd, "@SprocketFileID", sprocketfileID);
			cmd.ExecuteNonQuery();
		}

		public static SprocketFile Load(Guid sprocketfileID)
		{
			Database.Main.RememberOpenState();
			IDbCommand cmd = Database.Main.CreateCommand("SelectSprocketFile", CommandType.StoredProcedure);
			Database.Main.AddParameter(cmd, "@SprocketFileID", sprocketfileID);
			DataSet ds = Database.Main.GetDataSet(cmd);
			Database.Main.CloseIfWasntOpen();
			if (ds.Tables[0].Rows.Count == 0)
				throw new SprocketException("Cannot load SprocketFile with SprocketFileID of " + sprocketfileID + ". Record does not exist.");
			return new SprocketFile(ds.Tables[0].Rows[0]);
		}

		public static SprocketFile Load(string sprocketPath)
		{
			Database.Main.RememberOpenState();
			IDbCommand cmd = Database.Main.CreateCommand("SelectSprocketFileByPath", CommandType.StoredProcedure);
			Database.Main.AddParameter(cmd, "@SprocketPath", sprocketPath);
			DataSet ds = Database.Main.GetDataSet(cmd);
			Database.Main.CloseIfWasntOpen();
			if (ds.Tables[0].Rows.Count == 0)
				return null;
			return new SprocketFile(ds.Tables[0].Rows[0]);
		}

		public static SprocketFile[] Load(DataTable sprocketfileDataTable)
		{
			SprocketFile[] arr = new SprocketFile[sprocketfileDataTable.Rows.Count];
			for (int i = 0; i < sprocketfileDataTable.Rows.Count; i++)
				arr[i] = new SprocketFile(sprocketfileDataTable.Rows[i]);
			return arr;
		}

		public static SprocketFile[] LoadByOwner(Guid ownerID)
		{
			Database.Main.RememberOpenState();
			IDbCommand cmd = Database.Main.CreateCommand("SelectSprocketFilesByOwner", CommandType.StoredProcedure);
			Database.Main.AddParameter(cmd, "@OwnerID", ownerID);
			DataSet ds = Database.Main.GetDataSet(cmd);
			Database.Main.CloseIfWasntOpen();
			SprocketFile[] arr = new SprocketFile[ds.Tables[0].Rows.Count];
			for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
				arr[i] = new SprocketFile(ds.Tables[0].Rows[i]);
			return arr;
		}

		#endregion

		#region Custom Properties

		public string FileName
		{
			get { return Path.GetFileName(sprocketPath); }
		}

		public string PhysicalPath
		{
			get { return WebUtility.MapPath("datastore/filemanager/uploads/" + sprocketFileID + ".file"); }
		}

		public FileInfo FileInfo
		{
			get { return new FileInfo(PhysicalPath); }
		}

		#endregion

		public static SprocketFile Upload(HttpPostedFile upload, Guid? clientID, Guid? ownerID,
			Guid? parentFileID, string sprocketPath, string categoryCode, string moduleRegCode,
			string description)
		{
			if (upload.ContentLength > int.Parse(SprocketSettings.GetValue("FileManagerMaxUploadSizeBytes")))
				return null;

			SprocketFile file = new SprocketFile();
			file.sprocketFileID = Guid.NewGuid();
			file.clientID = clientID;
			file.ownerID = ownerID;
			file.parentFileID = parentFileID;
			file.sprocketPath = (sprocketPath.Trim('/') + "/" + Path.GetFileName(upload.FileName)).Trim('/');
			file.categoryCode = categoryCode;
			file.moduleRegCode = moduleRegCode;
			file.description = description;
			file.contentType = upload.ContentType;
			file.uploadDate = DateTime.Now;
			file.FileTypeExtension = Path.GetExtension(upload.FileName);
			upload.SaveAs(file.PhysicalPath);
			if (Database.Main.IsTransactionActive)
				file.Save();
			else
			{
				Database.Main.BeginTransaction();
				try
				{
					file.Save();
				}
				catch (Exception ex)
				{
					Database.Main.RollbackTransaction();
					file.EnsureFileDeleted();
					throw ex;
				}
				Database.Main.CommitTransaction();
			}
			return file;
		}

		public void EnsureFileDeleted()
		{
			if (File.Exists(PhysicalPath))
			{
				// Wrapping in a try/catch block ensures that if windows has locked the file
				// for some reason, the application doesn't crash. The file can always be
				// deleted later.
				try { File.Delete(PhysicalPath); }
				catch { } 
				// now delete any corresponding thumbnails
				if (!IsImage)
					return;
				foreach(string file in Directory.GetFiles(
					WebUtility.MapPath("datastore/filemanager/thumbnails"), sprocketFileID.ToString() + "*.*"))
					try { File.Delete(file);}
					catch { }
			}
		}

		public string GetThumbnailPhysicalPath(ThumbnailOptions options)
		{
			string thumbPath = WebUtility.MapPath("datastore/filemanager/thumbnails/" + options.GenerateFilename(sprocketFileID.Value));
			if (File.Exists(thumbPath))
			{
				if (new FileInfo(thumbPath).CreationTime > new FileInfo(PhysicalPath).CreationTime)
					return thumbPath;
				else
					File.Delete(thumbPath);
			}
			Image img = Image.FromFile(PhysicalPath);
			Image thumb = new Bitmap(options.OuterWidth, options.OuterHeight);
			Graphics gfx = Graphics.FromImage(thumb);
			gfx.CompositingQuality = CompositingQuality.HighQuality;
			gfx.SmoothingMode = SmoothingMode.HighQuality;
			gfx.InterpolationMode = InterpolationMode.HighQualityBicubic;
			Brush fill = new SolidBrush(options.BackgroundColor);
			Pen pen = new Pen(options.BorderColor, options.BorderWidth);
			pen.Alignment = PenAlignment.Inset;
			gfx.FillRectangle(fill, 0, 0, options.OuterWidth, options.OuterHeight);
			if(options.BorderWidth > 0)
				gfx.DrawRectangle(pen, 0, 0, options.OuterWidth-1, options.OuterHeight-1);
			Rectangle rect = new Rectangle(0, 0, img.Width, img.Height);
			if (img.Width > img.Height)
			{
				rect.Width = options.InnerWidth;
				rect.Height = (int)(((float)img.Height / (float)img.Width) * (float)options.InnerWidth);
			}
			else
			{
				rect.Height = options.InnerHeight;
				rect.Width = (int)(((float)img.Width / (float)img.Height) * (float)options.InnerHeight);
			}
			int xremain = options.OuterWidth - rect.Width;
			int yremain = options.OuterHeight - rect.Height;
			rect.X = xremain / 2;
			rect.Y = yremain / 2;
			if (xremain % 2 == 1)
				rect.Width++;
			if (yremain % 2 == 1)
				rect.Height++;
			gfx.DrawImage(img, rect);
			ImageCodecInfo[] encoders = ImageCodecInfo.GetImageEncoders();
			ImageCodecInfo encoder = null;
			for(int i=0; i<encoders.Length; i++)
				if(encoders[i].MimeType == "image/jpeg")
				{
					encoder = encoders[i];
					break;
				}
			if(encoder == null)
				throw new SprocketException("Can't create a thumbnail because no JPEG encoder exists.");
			EncoderParameters prms = new EncoderParameters(1);
			prms.Param[0] = new EncoderParameter(Encoder.Quality, 70L);
			thumb.Save(thumbPath, encoder, prms);
			img.Dispose();
			thumb.Dispose();
			return thumbPath;
		}

		public bool IsImage
		{
			get { return Utility.Utilities.MatchesAny(fileTypeExtension, "jpg", "gif", "png", "bmp"); }
		}

		public void RenderThumbnailToHttpOutput(ThumbnailOptions options)
		{
			HttpContext.Current.Response.ContentType = "image/jpeg";
			HttpContext.Current.Response.WriteFile(GetThumbnailPhysicalPath(options));
		}

		public void RenderFileTypeIconToHttpOutput()
		{
			Dictionary<string, KeyValuePair<string, string>> icons = GetFileTypeDefinitions();
			string ext = FileTypeExtension;
			if (!icons.ContainsKey(FileTypeExtension)) ext = "*";
			HttpContext.Current.Response.ContentType = "image/gif";
			HttpContext.Current.Response.WriteFile(icons[ext].Key);
		}

		public void RenderIconToHttpOutput()
		{
			if (IsImage)
				RenderThumbnailToHttpOutput(ThumbnailOptions.SprocketStandard);
			else
				RenderFileTypeIconToHttpOutput();
		}

		public void GetFileTypeInfo(out string iconPhysicalPath, out string fileTypeName)
		{
			Dictionary<string, KeyValuePair<string, string>> icons = GetFileTypeDefinitions();
			string ext = FileTypeExtension;
			if (!icons.ContainsKey(FileTypeExtension)) ext = "*";
			KeyValuePair<string, string> kvp = icons[ext];
			iconPhysicalPath = kvp.Key;
			fileTypeName = kvp.Value;
		}

		private Dictionary<string, KeyValuePair<string, string>> GetFileTypeDefinitions()
		{
			HttpApplicationState app = HttpContext.Current.Application;
			string xmlPath = WebUtility.MapPath("resources/filemanager/file-type-definitions.xml");
			DateTime timestamp = DateTime.MinValue;
			if (app["FileManager_FileTypeIcons_TimeStamp"] != null)
				timestamp = (DateTime)app["FileManager_FileTypeIcons_TimeStamp"];
			Dictionary<string, KeyValuePair<string, string>> icons;
			if (new FileInfo(xmlPath).LastWriteTime <= timestamp)
				icons = (Dictionary<string, KeyValuePair<string, string>>)app["FileManager_FileTypeIcons_TimeStamp"];
			else
			{
				icons = new Dictionary<string, KeyValuePair<string, string>>();
				XmlDocument doc = new XmlDocument();
				doc.Load(xmlPath);
				foreach (XmlNode node in doc.DocumentElement.ChildNodes)
					if (node.NodeType == XmlNodeType.Element)
					{
						string[] exts = ((XmlElement)node).GetAttribute("extension").Split(',');
						string iconPath = WebUtility.MapPath("resources/filemanager/file-type-icons/" + ((XmlElement)node).GetAttribute("icon"));
						string fileType = node.FirstChild.Value;
						foreach (string ext in exts)
							icons[ext.ToLower()] = new KeyValuePair<string, string>(iconPath, fileType);
					}
			}
			return icons;
		}

		public void Delete()
		{
			Database.Main.RememberOpenState();
			IDbCommand cmd = Database.Main.CreateCommand("DeleteSprocketFile", CommandType.StoredProcedure);
			Database.Main.AddParameter(cmd, "@SprocketFileID", sprocketFileID);
			cmd.ExecuteNonQuery();
			Database.Main.CloseIfWasntOpen();
			foreach (string file in Directory.GetFiles(WebUtility.MapPath("datastore/filemanager"),
				sprocketFileID.ToString() + "*.*", SearchOption.AllDirectories))
				try { File.Delete(file); }
				catch { }
			FileManager.Instance.NotifyFileDeleted(this);
		}
	}

	public class ThumbnailOptions
	{
		private int outerWidth = 60;
		private int outerHeight = 60;
		private int innerWidth = 40;
		private int innerHeight = 40;
		private Color backgroundColor = Color.White;
		private Color borderColor = Color.Transparent;
		private int borderWidth = 1;

		public ThumbnailOptions() { }
		public ThumbnailOptions(int outerWidth, int outerHeight, int innerWidth, int innerHeight,
			Color backgroundColor, Color borderColor, int borderWidth)
		{
			this.innerHeight = innerHeight;
			this.innerWidth = innerWidth;
			this.outerHeight = outerHeight;
			this.outerWidth = outerWidth;
			this.backgroundColor = backgroundColor;
			this.borderColor = borderColor;
			this.borderWidth = borderWidth;
		}

		public string GenerateFilename(Guid fileID)
		{
			return string.Format("{0}_{1}x{2}_{3}x{4}_{5}_{6}_{7}.thumb",
				fileID, outerWidth, outerHeight, innerWidth, innerHeight,
				backgroundColor.ToArgb(), borderColor.ToArgb(), borderWidth);
		}

		public static ThumbnailOptions SprocketStandard
		{
			get { return new ThumbnailOptions(60, 60, 50, 50, Color.White, Color.FromArgb(204, 204, 204), 1); }
		}

		#region Class Properties

		public int OuterWidth
		{
			get { return outerWidth; }
			set { outerWidth = value; }
		}

		public int OuterHeight
		{
			get { return outerHeight; }
			set { outerHeight = value; }
		}

		public int InnerWidth
		{
			get { return innerWidth; }
			set { innerWidth = value; }
		}

		public int InnerHeight
		{
			get { return innerHeight; }
			set { innerHeight = value; }
		}

		public Color BackgroundColor
		{
			get { return backgroundColor; }
			set { backgroundColor = value; }
		}

		public Color BorderColor
		{
			get { return borderColor; }
			set { borderColor = value; }
		}

		public int BorderWidth
		{
			get { return borderWidth; }
			set { borderWidth = value; }
		}

		#endregion
	}
}
