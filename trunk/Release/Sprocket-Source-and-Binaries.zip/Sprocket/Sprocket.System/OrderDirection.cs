using System;

namespace Sprocket.Data
{
	public enum OrderDirection
	{
		Ascending,
		Descending
	}
}