using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using Sprocket.Data;

namespace Sprocket.Security
{
	public partial class SecurityProvider
	{
	}
}
